const express = require('express');
const router = express.Router();
const path=require('path');
const mysql=require('../private/javascripts/database.js');
const Decimal=require('decimal.js');
const multer=require('multer');
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, `./public/images/${req.session.mailbox}`);
    },
    filename: function(req, file, cb) {
        cb(null, `${Date.now()}-${file.originalname}`)
    }
});
const upload = multer({ storage: storage });


//获取信息
router.get('/mailbox',function (req,res,next) {
    if(req.session.users==='商家') {
        res.end(`{"err":"success","mailbox":"${req.session.mailbox}"}`);
    }
    else{
        res.end('{"err":"noright"}');
    }
})


//上架商品
router.post('/upload', upload.array('imgfile', 40), function(req, res, next) {
    var files = req.files;
    if (!files[0]) {
        res.send('{"err":"fail"}');
        return;
    }
    console.log(files);

    let name=req.body.name;
    let desc=req.body.desc;
    let price=req.body.price;
    let storage=req.body.storage;
    let clas=req.body.class;

    let mailbox=req.session.mailbox;
    let shopId=req.session.userId;

    let sql=`select * from productClass where className="${clas}"`;
    mysql(sql,function (err,rows) {
        if(err){
            console.log(err);
            res.end('{"err":"fail"}');
            return;
        }
        if(rows.length===0){
            sql=`insert into productClass value(default ,"${clas}")`;
            mysql(sql,function (err,rows) {
                if(err){
                    console.log(err);
                    res.end('{"err":"fail"}');
                    return;
                }
                sql=`select * from productClass where className="${clas}"`;
                mysql(sql,function (err,rows) {
                    if(err){
                        console.log(err);
                        res.end('{"err":"fail"}');
                        return;
                    }
                    sql=`insert into product values(default ,'${rows[0].classId}','${name}','${desc}','${new Decimal(price)}','${files[0].filename}',${shopId},${storage},true)`;
                    mysql(sql,function (err,rows) {
                        if(err){
                            console.log(err);
                            res.end('{"err":"fail"}');
                            return;
                        }
                        res.end('{"err":"success"}');
                    });
                })

            });
        }
        else {
            sql=`insert into product values(default ,'${rows[0].classId}','${name}','${desc}','${new Decimal(price)}','${files[0].filename}',${shopId},${storage},true)`;
            mysql(sql,function (err,rows) {
                if(err){
                    console.log(err);
                    res.end('{"err":"fail"}');
                    return;
                }
                res.end('{"err":"success"}');
            });
        }
    })

});

//下架商品
router.post('/down', function(req, res, next) {
    let id=req.body.id;
    let sql=`update product set active=false where productId=${id}`;
    mysql(sql,function (err,rows) {
        if(err){
            res.end('{"err":"fail"}');
            return;
        }
        res.end('{"err":"success"}');
    });
})

//查看商品
router.post('/check',function (req,res,next) {
    let sql=`select * from product where shopId=${req.session.userId} and active=true`;
    mysql(sql,function (err,rows) {
        if(err){
            res.end('{"err":"fail"}');
            return;
        }
        let response='[';
        for(var i=0;i<rows.length;i++){
            response+='{';
            response+='"productId":"'+rows[i].productId+'"';
            response+=',"className":"'+rows[i].classId+'"';
            response+=',"productName":"'+rows[i].productName+'"';
            response+=',"description":"'+rows[i].description+'"';
            response+=',"price":"'+rows[i].price+'"';
            response+=',"imagePath":"'+rows[i].imagePath+'"';
            response+=',"quantity":"'+rows[i].quantity+'"';
            response+='}';
            response+=(i+1<rows.length?',':'');
        }
        response+=']';

        res.end(`{"err":"success","response":${response}}`);
    });
})

//修改商品
router.post('/change',function (req,res,next) {
    let name=req.body.name;
    let desc=req.body.desc;
    let price=req.body.price;
    let storage=req.body.storage;
    let path=req.files[0].path;

    let shopId=req.session.userId;

    let sql=`insert into product values(default ,,'${name}','${desc}','${new Decimal(price)}','${path}',${shopId},${storage},true)`;

    mysql(sql,function (err,rows) {
        if(err){
            res.end('{"err":"fail"}');
            return;
        }
        res.end('{"err":"success"}');
    });
})
module.exports = router;
