const express = require('express');
const path=require('path');
const router = express.Router();
const mysql=require('../private/javascripts/database.js');
const Decimal=require('decimal.js');

//获取信息
router.get('/mailbox',function (req,res,next) {
    if(req.session.users==='客户') {
        res.end(`{"err":"success","mailbox":"${req.session.mailbox}"}`);
    }
    else{
        res.end('{"err":"noright"}');
    }
})

//获取种类
router.get('/type',function (req,res,next) {
    let sql='select * from productClass';
    mysql(sql,function (err,rows) {
        if (err) {
            res.end('{"err":"fail"}');
            return;
        }
        let response = '[';
        for (var i = 0; i < rows.length; i++) {
            response += ',"className":"' + rows[i].classId + '"';
            response += (i + 1 < rows.length ? ',' : '');
        }
        response += ']';

        res.end(`{"err":"success","response":${response}}`);
    })
})

//获取商品
router.post('/check',function (req,res,next) {
    let clas=req.body.type;
    let productName=req.body.productName;
    let productId=req.body.productId;
    let sql='';
    if(clas!==""){
        sql=`select * from productClass, product where productClass.classId=product.classId and productClass.className="${type}"`;
    }
    else if(productName!==""){
        sql=`select * from product where productName like "%${productName}%" and active=true`;
    }
    else if(productId!==""){
        sql=`select * from product where productId=${productId} and active=true`;
    }
    else{
        sql=`select * from product`;
    }

    mysql(sql,function (err,rows) {
        if(err){
            res.end('{"err":"fail"}');
            return;
        }
        let response='[';
        for(var i=0;i<rows.length;i++){
            response+='{';
            response+='"productId":"'+rows[i].productId+'"';
            response+=',"className":"'+rows[i].classId+'"';
            response+=',"productName":"'+rows[i].productName+'"';
            response+=',"description":"'+rows[i].description+'"';
            response+=',"price":"'+rows[i].price+'"';
            response+=',"imagePath":"'+rows[i].imagePath+'"';
            response+=',"quantity":"'+rows[i].quantity+'"';
            response+='}';
            response+=(i+1<rows.length?',':'');
        }
        response+=']';

        res.end(`{"err":"success","response":${response}}`);
    });
})

//获取订单
router.post('/cart',function (req,res,next) {
    let sql=`select * from business where userId=${req.session.userId}`;
    let response='{"err":"success","cart":[';
    mysql(sql,function (err,rows) {
        if(err){
            res.end('{"err":"fail"}');
            return;
        }

        sql=`select * from singlebus,product where singlebus.productId=product.productId and businessId in(`;
        for(let i=0;i<rows.length;i++){
            sql+=`"${rows[i].businessId}"`;
            sql+=i<rows.length-1?',':'';
        }
        sql+=')';

        mysql(sql,function (err,singleRows) {
            if(err){
                res.end('{"err":"fail"}');
                return;
            }
            console.log(rows)
            console.log(singleRows)

            rows.forEach(function (item,i) {
                console.log('enter')
                response+='{';
                response+=`"total":"${item.total}",`;
                response+=`"buildTime":"${item.buildTime}",`;
                response+=`"address":"${item.address}",`;
                response+=`"send":"${item.send}",`;
                response+=`"receive":"${item.receive}",`;
                response+=`"ifDone":"${item.ifDone}",`;
                response+=`"product":[`;
                let count=false;
                for(let i=0;i<singleRows.length;i++){
                    if(singleRows[i].businessId===item.businessId){
                        if(count===false){
                            response+='{';
                            count=true;
                        }else{
                            response+=',{';
                        }
                        response+=`"imagePath":"${singleRows[i].imagePath}",`;
                        response+=`"productName":"${singleRows[i].productName}",`;
                        response+=`"price":"${singleRows[i].price}",`;
                        response+=`"description":"${singleRows[i].description}",`;
                        response+=`"quantity":"${singleRows[i].amount}"`;
                        response+='}';
                    }
                }
                response+=']';
                response+=i<rows.length-1?'},':'}';
            })
            response+=']}';
            console.log(response);
            res.end(response);
        })
    })
})

//购买[{productId:,quantity:},{}]
router.post('/buy', function(req, res, next) {
    let products=req.body.product;
    if(products.length===1){
        //确认余量
        let sql=`select price,quantity from product where productId=${products[0].productId}`;
        mysql(sql,function (err,rows) {
            if(err||rows.length===0) {
                res.end('{"err":"fail"}');
                return;
            }
            if(rows[0].quantity<products[0].quantity){
                res.end('{"err":"notenough"}');
                return;
            }
            //拿什么给钱？？？
            if((new Decimal(rows[0].price).mul(new Decimal(products[0].quantity)))){};

            //建立订单
            sql=`update product set quantity=quantity-${products[0].quantity} where productId=${products[0].productId}`;
            mysql(sql,function (err,rows) {
                if(err){
                    res.end('{"err":"fail"}');
                    return;
                }
            })
        })

    }
    else{

    }
});

//加入购物车
router.post('/addToCart',function (req,res,next) {
    let productId=parseInt(req.body.productId);
    let quantity=parseInt(req.body.quantity);

    let classId;
    let shopId;
    let price;
    let businessId;

    let sql = `select * from product where productId=${productId}`;
    mysql(sql, function (err, rows) {
        if(err){
            console.log(err);
            res.end('{"err":"fail"}');
            return
        }
        shopId = rows[0].shopId;
        price = rows[0].price;
        classId = rows[0].classId;
        console.log(shopId)
        console.log(price)
        console.log(classId)
    })

    //寻找是否已有购物车
    sql=`select * from business where userId="${req.session.userId}" and ifDone=false`;
    mysql(sql,function (err,rows) {
        if (err) {
            console.log(err);
            res.end('{"err":"fail"}');
            return
        }
        //已存在
        if(rows.length===1){
            let total=rows[0].total;
            businessId=rows[0].businessId;
            total=new Decimal(total).add(new Decimal(price).mul(new Decimal(quantity)));

            //更新business
            sql=`update business set total=${total} where businessId="${businessId}"`;
            mysql(sql,function (err) {
                if (err) {
                    console.log(err);
                    res.end('{"err":"fail"}');
                    return
                }
                //验证是否已存在该商品
                sql=`select * from singlebus where classId=${classId} and productId=${productId} and businessId="${businessId}"`;
                mysql(sql,function (err,rows) {
                    if (err) {
                        console.log(err);
                        res.end('{"err":"fail"}');
                        return
                    }
                    console.log(typeof rows[0].amount)
                    //订单细分
                    //已存在
                    if(rows.length===1){
                        sql=`update singlebus set amount=${rows[0].amount+quantity} where classId=${classId} and productId=${productId} and businessId="${businessId}"`;
                    }
                    //不存在
                    else{
                        sql=`insert into singlebus value(${classId},${productId},"${rows[0].businessId}",${new Decimal(price)},${quantity})`;
                    }
                    mysql(sql,function (err) {
                        if (err) {
                            console.log(err);
                            res.end('{"err":"fail"}');
                            return
                        }
                        res.end('{"err":"success"}');
                    });
                });
            })
        }
        //无购物车
        else {
            let UTS=Date.now();
            businessId=UTS.toString()+req.session.userId;
            let date=new Date(UTS);

            let time=date.getFullYear()+'/'+(date.getMonth()+1)+'/'+date.getDate()+'/'+date.getHours()+'/'+date.getMinutes()+'/'+date.getSeconds();

            //总价
            let total=new Decimal(price).mul(new Decimal(quantity));

            //订单
            sql = `insert into business value("${businessId}",${req.session.userId},${shopId},${total},"${time}","empty",false,false,false)`;
            mysql(sql,function (err,rows) {
                if (err) {
                    console.log(err);
                    res.end('{"err":"fail"}');
                    return
                }
                //订单细分
                sql=`insert into singlebus value(${classId},${productId},"${businessId}",${new Decimal(price)},${quantity})`;
                mysql(sql,function (err,rows) {
                    if (err) {
                        console.log(err);
                        res.end('{"err":"fail"}');
                        return
                    }
                    res.end('{"err":"success"}');
                });
            })

        }
    })
})

module.exports = router;