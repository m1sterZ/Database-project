const express = require('express');
const router = express.Router();
const mail = require('nodemailer');
const fs=require('fs');
const transportOption=require('../private/javascripts/config/mailOption.js');
const mysql=require('../private/javascripts/database.js')

/* GET home page. */
router.get('/', function(req, res, next) {
  if(req.session.mailbox===undefined)
    res.redirect('/view/index/login.html');
})
router.post('/email',function (req,res,next) {
  let mailbox=req.body.mailbox;
  let users=req.body.users;
  let verify="";
  for(var i=0;i<6;i++){
    verify+=Math.floor(Math.random()*10);
  }

  req.session.users=users;
  req.session.mailbox=mailbox;
  req.session.verify=verify;
  let transport=mail.createTransport(transportOption);
  var options ={
    from:'"机器人" 1045000455@qq.com',//YOURNAME将变为你邮件的名字
    to:mailbox,//收件人
    subject:'注册验证',    //主题
    text:"这是您在崔佛国际商品交易中心进行"+users+`注册的验证码${verify}<br>`
        +"在后续注册中请勿修改邮箱和账户类型信息,它们将不会再被记录<br>"
        +"如果您未进行过此操作，请忽略此邮件",        //正文
  };
  transport.sendMail(options,function (err, res) {
    if(err) {
      console.log(err);
      return;
    }
    else console.log(res);
  });
  res.end('{"err":"success"}');
})
router.post('/register',function (req,res,next) {
  let userName=req.body.userName;
  let password=req.body.password;
  if(req.session.verify!==req.body.verify) {
    res.end('{"err":"wrongCode"}');
    return;
  }
  let sql=`select mailbox from ${req.session.users==="商家"?"shopowner":"user"} where mailbox="${req.session.mailbox}"`;
  mysql(sql,function (err,rows) {
    if(err){
      res.end('{"err":"unknown"}');
      return;
    }
    if(rows.length!==0){
      res.end('{"err":"duplicate"}');
      return;
    }
    let sql=`insert into ${req.session.users==="商家"?"shopowner":"user"} values (default ,${req.session.users==="商家"?"default,":""}"${userName}","${password}","${req.session.mailbox}")`;
    mysql(sql,function (err) {
      if(err){
        res.end('{"err":"unknown"}');
        console.log(err);
        return;
      }

      if(req.session.users==="商家") {
        fs.mkdir(`./public/images/${req.session.mailbox}`,function (err) {
          if(err){
            res.end('{"err":"unknown"}');
            return console.log(err);
          }
          console.log("create image dir for "+req.session.mailbox);
        });
        res.end('{"err":"success"}');
      }
      else
        res.end('{"err":"success"}');
    })
  })
  // console.log(JSON.stringify({users:req.session.users,userName:userName,password:password,verify:req.session.verify,mailbox:req.session.mailbox}))

})

router.post('/login',function (req,res,next) {
  let users=req.body.users;
  let mailbox=req.body.mailbox;
  let password=req.body.password;
  let sql=`select * from ${users==="客户"?"user":"shopowner"} where mailbox="${mailbox}" and password="${password}"`;
  mysql(sql,function (err,rows) {
    if (err) {
      res.end('{"err":"unknown"}');
      return;
    }

    if(rows.length===0){
      res.end('{"err":"notexist"}');
      return;
    }
    req.session.users=users;
    req.session.mailbox=rows[0].mailbox;
    req.session.userId=rows[0].userId;
    if(req.session.users==="商家")
      res.end('{"err":"success","path":"/view/shopOwner/new_file.html"}');
    else
      res.end('{"err":"success","path":"/view/customer/userPage.html"}');
  })
})
module.exports = router;