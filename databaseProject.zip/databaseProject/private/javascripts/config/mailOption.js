let transportOption = {
    host:'smtp.qq.com',        //主机
    secureConnection:true,    //安全连接
    port:465,            //SMTP端口号
    auth:{
        user:"", //邮箱账号
        pass:""    //授权码
    }
};

module.exports=transportOption;