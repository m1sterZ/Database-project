const mysql=require("mysql");
const config=require("./config/databaseConfig");
let pool=mysql.createPool(config);
let connection=function(sql,callback){
    pool.getConnection(function (err,connection) {
        if(err)
            callback(err,null);
        else{
            connection.query(sql,function (err,rows) {
                connection.release();
                callback(err,rows);
            })
        }
    })
}

module.exports=connection;