function isEmail(mail){
  //定义正则表达式的变量:邮箱正则
  var reg = /^(([^()[\]\\.,;:\s@\"]+(\.[^()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  if(reg.test(mail)){
    document.getElementById("email_error_box").innerHTML = "<span class='success'><i class='success_icon'></i> 邮箱格式正确</span>"
    return;
  }
  else{
    document.getElementById("email_error_box").innerHTML = "<span class='error'><i class='error_icon'></i> 邮箱格式不正确</span>"
    return;
  }
}
function isUname(name){
  if(name.length > 20){
    document.getElementById("uname_error_box").innerHTML = "<span class='error'><i class='error_icon'></i> 账号名不多于20个字符</span>"
  }
  else if(name.length===0){
    document.getElementById("uname_error_box").innerHTML = "<span class='error'><i class='error_icon'></i> 账号名不能为空</span>"
  }
  else{
    document.getElementById("uname_error_box").innerHTML = ""
  }
}

$('button')[0].onclick=function () {
  let user=$('#user')[0].value;
  let mail=$('#email')[0].value;
  isEmail(mail);
  $.post('/email',{users:user,mailbox:mail});
}
$('button')[1].onclick=function () {
  let userName=$('#uname')[0].value;
  isUname(userName);
  let mail=$('#email')[0].value;
  isEmail(mail);
  let password=$('#pwd')[0].value;
  let verify=$('#check')[0].value;
  $.post('/register',{userName:userName,mailbox:mail,password:password,verify:verify}).done(function (data) {
    let parse=JSON.parse(data);
    if(parse.err!=="success"){
      if(parse.err==='wrongCode')
        alert('验证码错误');
      else if(parse.err==='duplicate')
        alert('此邮箱已注册过指定账户类型');
      else {
        alert('未知错误');
      }
    }else {
      alert('注册成功');
      window.location.href = './login.html';
    }
  });
}