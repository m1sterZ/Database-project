window.onload = function() {
    //用户信息
    $.get('/customer/mailbox').done(function (data) {
        let parse=JSON.parse(data);
    
        if(parse.err === 'noright'){
            alert('请登录');
            window.location.href = '../index/login.html';
        }
        else{
            $('#mailbox')[0].innerText = parse.mailbox;
            //获取购物车
            $.post('/customer/cart').done(function (data){
                alert(data)
                let parse = JSON.parse(data);
                if(parse.err==="fail"){
                    alert("未知错误");
                    return
                }
                else if(parse.cart.length===0){
                    alert("暂无");
                    return
                }
                let response = parse.cart;
                // let target = $('#cart')[0];
                let html = '';
                html += `<h4>购物车</h4>`;
                //服务器返回数据格式，
                //err为fail则是未知错误，为success则是正常
                //cart：！！购物车和订单一起！！，购物车的ifDone为false，订单的ifDone为true
                // {
                //     err:,
                //     cart:[
                //         {
                //             total:,//总价
                //             buildTime:,
                //             address:,
                //             send:,//二进制，true为已发货
                //             receive:,//二进制，true为已收货
                //             ifDone://二进制，true为已付款，显然这条为false则是购物车
                //             product:[//详尽列出每种具体商品信息
                //             {
                //                  imagePath:,
                //                  productName,
                //                  price:,//某商品价格
                //                  description:,//
                //                  quantity://某商品选购数量
                //             },
                //             {//第二种商品
                //                  ...
                //             },
                //                  ...
                //             ]
                //         },
                //         {//第二个购物车或订单
                //             ...
                //         },
                //             ...
                //     ]
                // }

                //遍历购物车和订单的所有商品
                for(let i = 0; i < response.length; i++){
                    //选择出购物车的商品
                    if(response[i].ifDone==false){
                        //部署到页面
                        html += `<table>`;
                        html += '<tr>';
                        html += '<td>商品</td><td>品名</td><td>描述</td><td>价格</td><td>购买量</td>';
                        html += '</tr>';
                        for(let j=0;j<response[i].product.length;j++) {
                            html += '<tr>';
                            html += `<td><img src="../../images/${$('#mailbox')[0].innerText}/${response[i].product[j].imagePath}" width="100px" height="auto"></td>`;
                            html += `<td>${response[i].product[j].productName}</td>`;
                            html += `<td>${response[i].product[j].description}</td>`;
                            html += `<td>${response[i].product[j].price}</td>`;
                            html += `<td>${response[i].product[j].quantity}</td>`;
                            html += '<tr>';
                        }
                    }

                    //按钮放最后
                    html += '<button id="delete">在购物车中删除</button>';
                    html += `<button id="buy">下单购买</button>`;
                }
                let div=document.createElement('div');
                div.className='itemBox w';
                document.body.appendChild(div);
                div.innerHTML=html;

                document.getElementById('delete').onclick = function() {
                    //productId给出要删除的商品Id
                    //服务器返回数据格式，
                    //err为fail则是未知错误，为success则是正常
                    //{err:}
                    $.post('/customer/deleteItem',{productId:""}).done(function() {
                        alert('已从购物车删除');
                    })
                }


                //服务器返回数据格式，
                //err为fail则是未知错误，为success则是正常
                //{err:}
                document.getElementById('buy').onclick = function() {
                    $.post('/customer/submitToBuy').done(function () {
                        alert('下单成功');
                    })
                }


                html = `<h4>订单记录</h4>`;
                //遍历购物车和订单的所有商品
                for(var i = 0; i < response.length; i++){
                    //选择出订单记录
                    if(response[i].ifDone===true){
                        //部署到页面
                        html += `<table>`;
                        html += '<tr>';
                        html += '<td>商品</td><td>品名</td><td>描述</td><td>价格</td>';
                        html += '</tr>';
                        for(let j=0;j<response[i].product.length;j++) {
                            html += '<tr>';
                            html += `<td><img src="../../images/${$('#mailbox')[0].innerText}/${response[i].product[j].imagePath}" width="100px" height="auto"></td>`;
                            html += `<td>${response[i].product[j].productName}</td>`;
                            html += `<td>${response[i].product[j].description}</td>`;
                            html += `<td>${response[i].product[j].price}</td>`;
                            html += `<td>${response[i].product[j].quantity}</td>`;
                            html += '</tr>';
                        }
                    }
                }
                let div_2=document.createElement('div');
                div_2.className='itemBox w';
                document.body.appendChild(div_2);
                div_2.innerHTML=html;
            })
        }
    })
}
