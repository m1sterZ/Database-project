let response;
window.onload = function () {
    //用户信息
    $.get('/customer/mailbox').done(function (data) {
        let parse=JSON.parse(data);

        if(parse.err==='noright'){
            alert('请登录');
            window.location.href='../index/login.html';
        }
        else{
            $('#mailbox')[0].innerText=parse.mailbox;
            //获取商品
            $.post('/customer/check',{type:"",productName:"",productId:window.location.href.split('?')[1].split('&')[0].split('=')[1]}).done(function (data) {
                alert(window.location.href.split('?')[1].split('&')[0].split('=')[1])
                alert(data)
                let parse = JSON.parse(data);
                let target = $('.itemBox')[0];
                response = parse.response;

                let html = '<table>';
                html+='<tr>';
                html+='<td>商品</td><td>品名</td><td>描述</td><td>价格</td><td>库存</td>';
                html+='</tr>';
                //可能多个，为简单起见形式统一
                for (var i = 0; i < parse.response.length; i++) {
                    html+='<tr>'
                    html += `<td><img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="100px" height="auto"></td>`;
                    html += `<td>${parse.response[i].productName}</td>`;
                    html += `<td>${parse.response[i].description}</td>`;
                    html += `<td>${parse.response[i].price}</td>`;
                    html += `<td>${window.location.href.split('?')[1].split('&')[1].split('=')[1]}</td>`;
                    html+='<tr>'
                }
                target.innerHTML = html;
            })
        }
    })
}

var cancel = document.getElementById('cancelbtn');
cancel.onclick = function () {
    window.location.href = `./itemPage.html?${window.location.href.split('?')[1].split('&')[0]}`;
    alert('已取消');
}

//服务器返回数据格式，
//err为fail则是未知错误，为success则是正常
//{err:}
var submit = document.getElementById('submitbtn');
submit.onclick = function () {
    $.post('/customer/submitToBuy',{productId:window.location.href.split('?')[1].split('&')[0].split('=')[1],
    quantity: window.location.href.split('?')[1].split('&')[1].split('=')[1]}).done(function () {
        alert('下单成功');
    })
}

/*var searchbtn = document.getElementById('searchbtn');
searchbtn.onclick = function() {
    
    //获取搜索结果
    $.post('/customer/search',{type:"",productName: searchText}).done(function (data) {
        alert(data)
        let parse = JSON.parse(data);
        let target = $('.itemBox')[0].getElementsByTagName('li');
        for(var i=0;i<parse.response.length;i++){
            let html = '';

            //路径不知道是啥，沛贤帮我改了吧
            html+=`<img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="100%" height="auto">`;
            html+=`<a href="./itemPage.html?productId=${parse.response[i].productId}"><h4>${parse.response[i].productName}</h4></a>`;
            target[i].innerHTML=html;
        }
    })


}*/