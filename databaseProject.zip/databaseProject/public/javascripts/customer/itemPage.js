//全局记下来
let response="";
window.onload = function() {
    //用户信息
    $.get('/customer/mailbox').done(function (data) {
        let parse=JSON.parse(data);

        if(parse.err==='noright'){
            alert('请登录');
            window.location.href='../index/login.html';
        }
        else{
            $('#mailbox')[0].innerText=parse.mailbox;
            //获取商品
            $.post('/customer/check',{type:"",productName:"",productId:window.location.href.split('?')[1].split('=')[1]}).done(function (data) {
                alert(window.location.href.split('?')[1].split('=')[1])
                alert(data)
                let parse=JSON.parse(data);
                let target=$('.itemPic')[0];
                response=parse.response[0];
                //只有1个，为简单起见形式统一
                for(let i=0;i<parse.response.length;i++){
                    let html='';
                    html+=`<img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="100%" height="auto">`;
                    target.innerHTML=html;


                    html='';
                    html+='<ul>';
                    html+=`<label>品名：</label><li>${parse.response[i].productName}</br></li>`;
                    html+=`<label>描述：</label><li>${parse.response[i].description}</br></li>`;
                    html+=`<label>价格：</label><li>${parse.response[i].price}</br></li>`;
                    html+=`<label>库存：</label><li>${parse.response[i].quantity}</br></li>`;
                    $('#desc')[0].innerHTML=html;
                }
            })
        }
    })
}

document.getElementById('addToCart').onclick = function() {
    let select = $('#quantity')[0];
    let selectedOption = select.options[select.options.selectedIndex];
    //发送加入购物车的请求
    $.post('/customer/addToCart',{productId:window.location.href.split('?')[1].split('=')[1],quantity:selectedOption.innerText}).done(function (data){
        let parse=JSON.parse(data);
        if(parse.err==="fail"){
            alert('未知错误')
        }
        else {
            alert('已加入购物车')
        }
    })
}

document.getElementById('buy').onclick = function() {
    let select = $('#quantity')[0];
    let selectedOption = select.options[select.options.selectedIndex];
    alert(`./paymentPage.html?productId=${response.productId}&quantity=${selectedOption.innerText}`)
    window.location.href = `./paymentPage.html?productId=${response.productId}&quantity=${selectedOption.innerText}`;
}

//搜索之后把它变成userPage那样显示搜索结果
//把itemBody整个div替换掉了
document.getElementById('searchbtn').onclick = function() {
    // window.location.reload();
    let searchText = document.getElementById('searchText').value;
    //获取搜索结果
    $.post('/customer/check',{type:"",productName: searchText,productId:""}).done(function (data) {
        alert(data)
        let parse=JSON.parse(data);
        let body = $('.itemBox')[0];
        let html = '';
        html += `<div class="box w">`;
        html += `<div class="box-bd">`;
        for(var i = 0; i < 10; i++){
            html += `<li></li>`;
        }
        html += `</div>`;
        html += `</div>`;
        let target = $('.box-bd')[0].getElementsByTagName('li');
        for(var i = 0; i < parse.response.length; i++){
            let lihtml='';

            //路径不知道是啥，沛贤帮我改了吧
            lihtml += `<img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="100%" height="auto">`;
            lihtml += `<a href="./itemPage.html?productId=${parse.response[i].productId}"><h4>${parse.response[i].productName}</h4></a>`;
            target[i].innerHTML = lihtml;
        }
        body.innerHTML = html;
    })
}