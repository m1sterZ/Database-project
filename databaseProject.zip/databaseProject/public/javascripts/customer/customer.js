
window.onload = function (){
    //用户信息
    $.get('/customer/mailbox').done(function (data) {
    let parse=JSON.parse(data);

    if(parse.err === 'noright'){
        alert('请登录');
        window.location.href = '../index/login.html';
    }
    else{
            $('#mailbox')[0].innerText = parse.mailbox;
            //获取商品
            $.post('/customer/check',{type:"",productName:"",productId:""}).done(function (data) {
                alert(data)
                let parse = JSON.parse(data);
                let target = $('.box-bd')[0].getElementsByTagName('li');
                for(var i = 0; i < parse.response.length; i++){
                    let html = '';
                    html += `<img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="100%" height="auto">`;
                    html += `<a href="./itemPage.html?productId=${parse.response[i].productId}"><h4>${parse.response[i].productName}</h4></a>`;
                    target[i].innerHTML=html;
                }
            })


            //获取分类

            //服务器返回数据格式，
            //err为fail则是未知错误，为success则是正常.type为商品种类
            //{err:,
            // type:[...,  ...,  ...]
            // }
            $.post('/customer/type').done(function (data) {
                let parse=JSON.parse(data);

            })
        }
    })
}

var searchbtn = document.getElementById('searchbtn');

searchbtn.onclick = function() {
    //window.location.reload();
    //获取搜索结果
    var searchText = document.getElementById('searchText').value;
    $.post('/customer/check',{type:"",productName: searchText,productId:""}).done(function (data) {
        alert(data)
        let parse=JSON.parse(data);
        //请求成功后刷新li标签里面的内容
        let target=$('.box-bd')[0].getElementsByTagName('li');
        for(let i=0;i<target.length;i++)
            target[i].innerHTML='';

        for(let i = 0; i < parse.response.length; i++){
            let html = '';
            html += `<img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="100%" height="auto">`;
            html += `<a href="./itemPage.html?productId=${parse.response[i].productId}"><h4>${parse.response[i].productName}</h4></a>`;
            target[i].innerHTML=html;
        }
        var restext = '搜索结果';
        $('#subtitle')[0].innerText = restext;
    })
}
