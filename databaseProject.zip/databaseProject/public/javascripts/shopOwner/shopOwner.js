$('#to_top').click(function(){
    $('html,body').scrollTop(0);
})
document.getElementById("left").innerHTML = "崔佛国际商品交易中心(Trevor's international commodity trading center)欢迎您";
document.getElementById("left").innerHTML = "本产品由\"今天上哪吃饭队\"提供，本产品最终解释权为\"今天上哪吃饭队\"所有";
// 将按钮和盒子拿出来
var btn = document.getElementsByTagName("button")
var div = document.getElementsByClassName('content');
// 每一个button上面绑定事件
for(var n = 0; n < btn.length; n++) {
    //生成闭包的立即函数
    (function(i) {
        btn[n].onclick = function() {
            for(var m = 0; m < btn.length; m++) {
                btn[m].className = ""; //清空效果
                div[m].style.display = "none";
            }
            //当前点击的button设置变化
            this.className = "active";
            div[i].style.display = "block";
        }
    }(n))
}


let getProduct=function(){
    $.post('/shopOwner/check').done(function (data) {
        alert(data)
        let parse=JSON.parse(data);
        let target=$('.content')[0];
        let html='';
        for(var i=0;i<parse.response.length;i++){
            html+=`<a href="#" onclick="alert(${JSON.stringify(parse.response[i])});return false;">`;
            html+=`<img src="../../images/${$('#mailbox')[0].innerText}/${parse.response[i].imagePath}" width="200px" height="auto">`;
            html+=`</a>`;
        }
        target.innerHTML=html;
    })
}

//获取商家邮箱
$.get('/shopOwner/mailbox').done(function (data) {
    let parse=JSON.parse(data);

    if(parse.err==='noright'){
        alert('请登录');
        window.location.href='../index/login.html';
    }
    else{
        $('#mailbox')[0].innerText=parse.mailbox;
    }
})

//获取产品
getProduct();

//上传
document.querySelector('#upload').onclick= function (){
    var fileinput = document.getElementById('file');
    var xhr = new XMLHttpRequest();
    var formdata = new FormData();
    var progress = document.querySelector('progress');
    var div=$('.content')[1];
    var name=div.getElementsByTagName('input')[0].value;
    var price=div.getElementsByTagName('input')[1].value;
    var desc=div.getElementsByTagName('input')[2].value;
    var storage=div.getElementsByTagName('input')[3].value;
    var clas=div.getElementsByTagName('input')[4].value;

    var files = fileinput.files
    if (!files[0]) {
        alert('请先选择图片，再上传！')
        return
    }



    formdata.append('imgfile', files[0], files[0].name);
    formdata.append('name',name);
    formdata.append('price',price);
    formdata.append('desc',desc);
    formdata.append('storage',storage);
    formdata.append('class',clas);

    xhr.open('POST', '/shopOwner/upload')
    xhr.onload = () => {
        if (xhr.status === 200 ) {
            let parse=JSON.parse(xhr.responseText);
            if(parse.err==='success')
                alert('上传成功！');
            else
                alert('失败');
        }
    }
    xhr.send(formdata)
    xhr.upload.onprogress = e => {
        if (e.lengthComputable) {
            var progressWrap = document.querySelector('.progress')
            progressWrap.style.display = "flex"
            var percentComplete = e.loaded / e.total * 100
            progress.value = percentComplete

            if (percentComplete >= 100) {
                progress.value = 0
                progressWrap.style.display = "none"
            }
        }
    }

}